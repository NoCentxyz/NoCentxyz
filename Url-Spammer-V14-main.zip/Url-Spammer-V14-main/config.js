const config = {
    TOKEN: "",
    authorID: "",
    url: "",
    serverID: "",
    log: "",
    status: "true",
    botRun: "5000"

}

module.exports = config